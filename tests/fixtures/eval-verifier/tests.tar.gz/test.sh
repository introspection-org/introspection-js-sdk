#!/bin/sh
mkdir -p /logs/verifier
echo "verifier ran"
echo '{"reward": 1, "ran": 1}' > /logs/verifier/result.json
